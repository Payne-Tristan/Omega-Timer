import { useTimers } from "@/hooks/use-timers";
import { format } from "date-fns";
import { Timer, Clock, Trash2 } from "lucide-react";

export function HistoryList() {
  const { data: timers, isLoading } = useTimers();

  if (isLoading) return <div className="text-neutral-500 text-center py-4">Loading mission logs...</div>;
  if (!timers || timers.length === 0) return <div className="text-neutral-600 text-center py-4 text-sm font-mono uppercase tracking-widest">No flight data recorded</div>;

  return (
    <div className="w-full space-y-3">
      <h3 className="text-xs font-display uppercase tracking-widest text-neutral-400 mb-4 border-b border-neutral-800 pb-2">
        Mission Log
      </h3>
      <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
        {timers.map((timer) => (
          <div 
            key={timer.id}
            className="flex items-center justify-between p-3 rounded bg-neutral-900/50 border border-neutral-800 hover:border-neutral-700 transition-colors group"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-full bg-neutral-800 text-neutral-400">
                {timer.type === 'chronograph' ? <Clock size={14} /> : <Timer size={14} />}
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-mono text-neutral-200">
                  {formatDuration(timer.duration)}
                </span>
                <span className="text-[10px] text-neutral-500 uppercase tracking-wider font-display">
                   {timer.type} • {timer.label || 'Unlabeled'}
                </span>
              </div>
            </div>
            
            <span className="text-[10px] text-neutral-600 font-mono">
              {timer.completedAt ? format(new Date(timer.completedAt), "dd MMM HH:mm") : "-"}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function formatDuration(ms: number) {
  const minutes = Math.floor(ms / 60000);
  const seconds = Math.floor((ms % 60000) / 1000);
  const centis = Math.floor((ms % 1000) / 10);
  return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}.${centis.toString().padStart(2, '0')}`;
}
