import { cn } from "@/lib/utils";

interface DigitalDisplayProps {
  value: number; // in milliseconds
  label?: string;
  isEditing?: boolean;
}

export function DigitalDisplay({ value, label, isEditing = false }: DigitalDisplayProps) {
  const formatTime = (ms: number) => {
    const hours = Math.floor(ms / 3600000);
    const minutes = Math.floor((ms % 3600000) / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    const centiseconds = Math.floor((ms % 1000) / 10);

    return {
      h: hours.toString().padStart(2, '0'),
      m: minutes.toString().padStart(2, '0'),
      s: seconds.toString().padStart(2, '0'),
      cs: centiseconds.toString().padStart(2, '0')
    };
  };

  const time = formatTime(value);

  return (
    <div className={cn(
      "font-mono bg-[#1a1a1a] border border-neutral-700 rounded-lg px-4 py-2 flex items-center gap-1 shadow-[inset_0_2px_8px_rgba(0,0,0,0.5)]",
      isEditing && "ring-2 ring-primary/50 border-primary"
    )}>
      <div className="flex flex-col items-center">
        <span className="text-2xl text-[#C5E1A5] font-bold tracking-widest leading-none drop-shadow-[0_0_8px_rgba(197,225,165,0.2)]">
          {time.h}:{time.m}:{time.s}
        </span>
      </div>
      <span className="text-sm text-neutral-500 font-medium mt-1">.{time.cs}</span>
      
      {label && (
        <span className="ml-3 text-xs uppercase text-neutral-500 font-display tracking-widest border-l border-neutral-700 pl-3">
          {label}
        </span>
      )}
    </div>
  );
}
