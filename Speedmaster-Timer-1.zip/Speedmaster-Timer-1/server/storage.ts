import { db } from "./db";
import {
  timerHistory,
  type InsertTimerHistory,
  type TimerHistory
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getTimerHistory(): Promise<TimerHistory[]>;
  createTimerHistory(entry: InsertTimerHistory): Promise<TimerHistory>;
}

export class DatabaseStorage implements IStorage {
  async getTimerHistory(): Promise<TimerHistory[]> {
    return await db.select().from(timerHistory).orderBy(desc(timerHistory.completedAt));
  }

  async createTimerHistory(entry: InsertTimerHistory): Promise<TimerHistory> {
    const [newItem] = await db.insert(timerHistory).values(entry).returning();
    return newItem;
  }
}

export const storage = new DatabaseStorage();
