import { Play, Pause, RotateCcw, Save } from "lucide-react";
import { cn } from "@/lib/utils";

interface ControlProps {
  isRunning: boolean;
  onStartStop: () => void;
  onReset: () => void;
  onSave?: () => void;
  canSave: boolean;
  disabled?: boolean;
}

export function Controls({ isRunning, onStartStop, onReset, onSave, canSave, disabled }: ControlProps) {
  return (
    <div className="flex flex-col gap-4 absolute -right-4 top-1/2 -translate-y-1/2 z-50">
      {/* Top Pusher (Start/Stop) */}
      <Pusher 
        onClick={onStartStop} 
        variant="primary"
        label={isRunning ? "STOP" : "START"}
        disabled={disabled}
      />

      <div className="h-16" /> {/* Crown spacing gap */}

      {/* Bottom Pusher (Reset) */}
      <Pusher 
        onClick={onReset} 
        variant="secondary"
        label="RESET"
        disabled={disabled}
      />
    </div>
  );
}

function Pusher({ onClick, variant, label, disabled }: { onClick: () => void, variant: 'primary' | 'secondary', label: string, disabled?: boolean }) {
  return (
    <div className="relative group flex items-center">
      <div className="absolute right-full mr-2 opacity-0 group-hover:opacity-100 transition-opacity text-[10px] font-display tracking-widest text-neutral-400 bg-black/80 px-2 py-1 rounded">
        {label}
      </div>
      
      <button
        onClick={onClick}
        disabled={disabled}
        className={cn(
          "w-6 h-12 rounded-l-sm bg-gradient-to-r from-neutral-300 via-neutral-100 to-neutral-400 shadow-[2px_2px_5px_rgba(0,0,0,0.5)] active:translate-x-[2px] active:shadow-none transition-all duration-100 border-r border-neutral-500",
          disabled && "opacity-50 cursor-not-allowed active:translate-x-0"
        )}
      >
        <div className="w-full h-full flex flex-col justify-between py-1 px-[2px]">
           {[...Array(6)].map((_, i) => (
             <div key={i} className="w-full h-[1px] bg-neutral-400" />
           ))}
        </div>
      </button>
      
      {/* Pusher Stem */}
      <div className="w-3 h-6 bg-neutral-600 -ml-[1px] z-[-1]" />
    </div>
  );
}
