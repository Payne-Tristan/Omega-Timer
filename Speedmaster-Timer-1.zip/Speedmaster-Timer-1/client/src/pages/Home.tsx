import { useState, useEffect, useRef } from "react";
import { WatchFace } from "@/components/WatchFace";
import { DigitalDisplay } from "@/components/DigitalDisplay";
import { Controls } from "@/components/Controls";
import { HistoryList } from "@/components/HistoryList";
import { useCreateTimer } from "@/hooks/use-timers";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Save } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";

type Mode = "clock" | "chronograph" | "timer";

export default function Home() {
  const [mode, setMode] = useState<Mode>("clock");
  const [currentTime, setCurrentTime] = useState(new Date());
  
  // Chronograph/Timer state
  const [isRunning, setIsRunning] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0); // ms
  const [timerDuration, setTimerDuration] = useState(60000); // Default 1 min timer
  
  // Refs for animation loop
  const requestRef = useRef<number>();
  const startTimeRef = useRef<number>(0);
  const previousElapsedRef = useRef<number>(0);

  const createTimerMutation = useCreateTimer();
  const [isSaveDialogOpen, setIsSaveDialogOpen] = useState(false);
  const [saveLabel, setSaveLabel] = useState("");

  // Update real-time clock
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Animation Loop for high-precision timing
  const animate = (time: number) => {
    if (startTimeRef.current === 0) startTimeRef.current = time;
    const delta = time - startTimeRef.current;
    
    if (mode === "timer") {
       // Count DOWN logic
       const newElapsed = previousElapsedRef.current + delta;
       // Clamp to duration if counting up, or just track elapsed for countdown
       if (newElapsed >= timerDuration) {
         setElapsedTime(timerDuration);
         setIsRunning(false);
         // Play sound?
       } else {
         setElapsedTime(newElapsed);
         requestRef.current = requestAnimationFrame(animate);
       }
    } else {
       // Count UP logic (Chronograph)
       setElapsedTime(previousElapsedRef.current + delta);
       requestRef.current = requestAnimationFrame(animate);
    }
  };

  useEffect(() => {
    if (isRunning) {
      startTimeRef.current = 0; // Reset frame start reference
      requestRef.current = requestAnimationFrame(animate);
    } else {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
      previousElapsedRef.current = elapsedTime; // Store accumulated time
    }
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [isRunning]);

  // Mode Switching Logic
  const handleModeChange = (newMode: string) => {
    setMode(newMode as Mode);
    // Reset chrono when switching modes? No, keeps running in background usually.
    // For simplicity, let's pause.
    setIsRunning(false);
    setElapsedTime(0);
    previousElapsedRef.current = 0;
  };

  const handleStartStop = () => {
    setIsRunning(!isRunning);
  };

  const handleReset = () => {
    setIsRunning(false);
    setElapsedTime(0);
    previousElapsedRef.current = 0;
  };

  const handleSave = async () => {
    if (elapsedTime === 0) return;
    
    await createTimerMutation.mutateAsync({
      type: mode === "timer" ? "countdown" : "chronograph",
      duration: elapsedTime,
      label: saveLabel || "Untitled Mission",
    });
    
    setIsSaveDialogOpen(false);
    setSaveLabel("");
    handleReset();
  };

  const displayedTime = mode === "timer" 
    ? Math.max(0, timerDuration - elapsedTime) 
    : elapsedTime;

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-foreground flex flex-col items-center py-8 px-4 overflow-hidden">
      
      {/* Header / Mode Switcher */}
      <div className="w-full max-w-md z-10 mb-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-display font-bold tracking-widest text-neutral-100">
            CHRONOS<span className="text-[#C5E1A5]">.</span>X
          </h1>
          <div className="text-[10px] font-mono text-neutral-500 uppercase tracking-widest">
            {new Date().toLocaleDateString(undefined, { weekday: 'short', day: '2-digit', month: 'short' }).toUpperCase()}
          </div>
        </div>

        <Tabs defaultValue="clock" value={mode} onValueChange={handleModeChange} className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-neutral-900 border border-neutral-800">
            <TabsTrigger value="clock" className="font-display tracking-widest text-xs data-[state=active]:bg-neutral-800 data-[state=active]:text-[#C5E1A5]">CLOCK</TabsTrigger>
            <TabsTrigger value="chronograph" className="font-display tracking-widest text-xs data-[state=active]:bg-neutral-800 data-[state=active]:text-[#C5E1A5]">CHRONO</TabsTrigger>
            <TabsTrigger value="timer" className="font-display tracking-widest text-xs data-[state=active]:bg-neutral-800 data-[state=active]:text-[#C5E1A5]">TIMER</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Main Watch Interface */}
      <div className="relative w-full max-w-lg mb-8">
        <WatchFace 
          mode={mode}
          currentTime={currentTime}
          elapsedTime={mode === "timer" ? elapsedTime : elapsedTime} // WatchFace needs logic adjustment if timer runs backwards visually
          isRunning={isRunning}
          timerDuration={timerDuration}
        />
        
        {/* Physical Pushers mapped to UI */}
        <Controls 
          isRunning={isRunning} 
          onStartStop={handleStartStop}
          onReset={handleReset}
          canSave={elapsedTime > 0 && !isRunning}
          disabled={mode === "clock"}
          onSave={() => setIsSaveDialogOpen(true)}
        />
      </div>

      {/* Digital Readout & Actions */}
      <div className="w-full max-w-md space-y-6 z-10">
        
        {mode !== "clock" && (
          <div className="flex justify-between items-end gap-4">
             <div className="flex-1">
                <DigitalDisplay 
                  value={displayedTime} 
                  label={mode === "timer" ? "REMAINING" : "ELAPSED"} 
                />
             </div>
             
             {/* Timer Settings Input */}
             {mode === "timer" && !isRunning && elapsedTime === 0 && (
               <div className="flex items-center gap-2">
                 <Input 
                   type="number" 
                   value={timerDuration / 1000 / 60} 
                   onChange={(e) => setTimerDuration(Number(e.target.value) * 60 * 1000)}
                   className="w-20 bg-neutral-900 border-neutral-800 text-right font-mono"
                 />
                 <span className="text-xs text-neutral-500 font-display">MIN</span>
               </div>
             )}

             {/* Save Button */}
             <Dialog open={isSaveDialogOpen} onOpenChange={setIsSaveDialogOpen}>
               <DialogTrigger asChild>
                 <Button 
                   variant="outline" 
                   size="icon" 
                   className="bg-neutral-900 border-neutral-700 hover:bg-neutral-800 hover:text-[#C5E1A5]"
                   disabled={elapsedTime === 0 || isRunning}
                 >
                   <Save size={18} />
                 </Button>
               </DialogTrigger>
               <DialogContent className="bg-[#111] border-neutral-800 text-neutral-100">
                 <DialogHeader>
                   <DialogTitle className="font-display tracking-widest">SAVE MISSION LOG</DialogTitle>
                 </DialogHeader>
                 <div className="space-y-4 py-4">
                   <div className="space-y-2">
                     <Label className="text-xs uppercase text-neutral-500">Duration</Label>
                     <div className="font-mono text-2xl text-[#C5E1A5]">
                        <DigitalDisplay value={elapsedTime} />
                     </div>
                   </div>
                   <div className="space-y-2">
                     <Label className="text-xs uppercase text-neutral-500">Mission Label</Label>
                     <Input 
                        placeholder="e.g. Apollo 11 Launch" 
                        value={saveLabel}
                        onChange={(e) => setSaveLabel(e.target.value)}
                        className="bg-neutral-900 border-neutral-700 text-white font-mono"
                     />
                   </div>
                 </div>
                 <DialogFooter>
                    <Button 
                      onClick={handleSave} 
                      disabled={createTimerMutation.isPending}
                      className="bg-[#C5E1A5] text-black hover:bg-[#aed581] font-bold tracking-wider"
                    >
                      {createTimerMutation.isPending ? "SAVING..." : "CONFIRM LOG"}
                    </Button>
                 </DialogFooter>
               </DialogContent>
             </Dialog>
          </div>
        )}

        <HistoryList />
      </div>
      
      {/* Background Ambience */}
      <div className="fixed inset-0 pointer-events-none z-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-neutral-900/50 via-[#050505] to-black" />
    </div>
  );
}
