import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface WatchFaceProps {
  mode: "clock" | "chronograph" | "timer";
  currentTime: Date;
  elapsedTime: number; // in ms
  isRunning: boolean;
  timerDuration?: number; // total duration for countdown
}

export function WatchFace({ mode, currentTime, elapsedTime, isRunning, timerDuration }: WatchFaceProps) {
  const [smoothSecond, setSmoothSecond] = useState(0);

  // Time calculations
  const hours = currentTime.getHours() % 12;
  const minutes = currentTime.getMinutes();
  const seconds = currentTime.getSeconds();
  
  // Continuous rotation for clock hands
  const hourDeg = (hours + minutes / 60) * 30;
  const minuteDeg = (minutes + seconds / 60) * 6;
  const secondDeg = seconds * 6;

  // Chronograph/Timer calculations (elapsedTime is in ms)
  const chronoSeconds = (elapsedTime / 1000) % 60;
  const chronoMinutes = Math.floor(elapsedTime / 1000 / 60) % 60;
  const chronoHours = Math.floor(elapsedTime / 1000 / 3600) % 12;

  const chronoSecondDeg = chronoSeconds * 6;
  const chronoMinuteDeg = chronoMinutes * 6;
  const chronoHourDeg = chronoHours * 30;

  // Timer reverse rotation
  const timerProgress = timerDuration ? 1 - (elapsedTime / timerDuration) : 0;
  // If in timer mode, the main hand could show remaining seconds or progress
  
  // Sub-dial logic
  // Left: Real-time Seconds (always running)
  const subDialLeftDeg = secondDeg; 
  
  // Bottom: Chrono Hours (accumulates)
  const subDialBottomDeg = chronoHourDeg;

  // Right: Chrono Minutes (accumulates)
  const subDialRightDeg = chronoMinuteDeg;

  // Determine main central hand based on mode
  let mainHandDeg = 0;
  if (mode === "clock") {
    mainHandDeg = 0; // Parked at 12 usually for pure clock, or running chrono if active? 
    // Speedmaster style: Central hand IS the chronograph hand. It stays at 12 unless chrono is running.
    // The actual seconds are on the left sub-dial.
    mainHandDeg = isRunning || elapsedTime > 0 ? chronoSecondDeg : 0;
  } else if (mode === "chronograph") {
    mainHandDeg = chronoSecondDeg;
  } else if (mode === "timer") {
    // For timer, maybe run backwards or show remaining seconds?
    // Let's make it sweep backwards from 0 (360) for visual effect or just show elapsed
    mainHandDeg = -chronoSecondDeg; 
  }

  // Generate Tachymeter scale ticks
  const tachyTicks = Array.from({ length: 240 }).map((_, i) => i);

  return (
    <div className="relative w-full aspect-square max-w-[500px] mx-auto">
      {/* Case / Bezel Outer */}
      <div className="absolute inset-0 rounded-full bg-neutral-800 shadow-2xl shadow-black border-[1px] border-neutral-700">
        {/* Tachymeter Bezel */}
        <div className="absolute inset-1 rounded-full bg-black border-[12px] border-neutral-900 shadow-inner">
           {/* Tachymeter numbers would go here roughly */}
           <div className="absolute top-2 left-1/2 -translate-x-1/2 text-[8px] font-display text-neutral-400 tracking-widest">TACHYMETRE</div>
        </div>

        {/* Bezel (Tachymeter) */}
        <div className="absolute inset-0 rounded-full bg-[#111] shadow-[0_0_20px_rgba(0,0,0,0.8)] border-[12px] border-neutral-900 ring-2 ring-neutral-800 ring-inset">
          {/* Tachymeter Ticks (Visual representation) */}
          {[...Array(60)].map((_, i) => {
            const angle = i * 6;
            const values = {
              0: "TACHYMETRE",
              5: "500",
              10: "400",
              15: "300",
              20: "240",
              25: "200",
              30: "180",
              35: "160",
              40: "140",
              45: "120",
              50: "100",
              55: "80",
            };
            const label = values[i as keyof typeof values];
            
            return (
              <div
                key={`bezel-${i}`}
                className="absolute left-1/2 top-1"
                style={{ transform: `translateX(-50%) rotate(${angle}deg)`, transformOrigin: "50% 250px" }}
              >
                {label && (
                  <span className={cn(
                    "text-[7px] font-bold text-neutral-400 select-none",
                    i === 0 ? "text-[6px] -translate-y-1" : ""
                  )}>
                    {label}
                  </span>
                )}
              </div>
            );
          })}
        </div>
        
        {/* Crystal Glass Reflection */}
        <div className="absolute inset-4 rounded-full glass-reflection z-50 pointer-events-none opacity-30" />
        
        {/* Dial */}
        <div className="absolute inset-[15%] rounded-full bg-[#0d0d0d] shadow-[inset_0_0_40px_rgba(0,0,0,1)] border border-neutral-900">
          
          {/* Main Hour Markers */}
          {[...Array(12)].map((_, i) => (
            <div
              key={i}
              className="absolute w-[3px] h-[18px] bg-[#f0f0f0] left-[calc(50%-1.5px)] top-[0.5%]"
              style={{ 
                transform: `rotate(${i * 30}deg)`, 
                transformOrigin: "50% 160px" 
              }}
            >
              {/* Lume strip */}
              <div className="absolute inset-x-[0.5px] inset-y-[2px] bg-[#d9e6cc] opacity-90 shadow-[0_0_2px_#C5E1A5]" />
              
              {/* 12 o'clock marker dots */}
              {i === 0 && (
                 <div className="absolute -top-6 left-[50%] -translate-x-[50%] flex gap-3">
                   <div className="w-2.5 h-2.5 rounded-full bg-[#d9e6cc] shadow-[0_0_3px_#C5E1A5]" />
                   <div className="w-2.5 h-2.5 rounded-full bg-[#d9e6cc] shadow-[0_0_3px_#C5E1A5]" />
                 </div>
              )}
            </div>
          ))}

          {/* Precision Seconds/Minute Ticks (Speedmaster 1/5th style) */}
          {[...Array(300)].map((_, i) => {
            const isSecond = i % 5 === 0;
            if (isSecond) return null;
            return (
              <div
                key={`tick-${i}`}
                className="absolute w-[0.5px] h-[4px] bg-neutral-600 left-[calc(50%-0.25px)] top-[1%]"
                style={{ 
                  transform: `rotate(${i * 1.2}deg)`, 
                  transformOrigin: "50% 158px" 
                }}
              />
            );
          })}

          {/* Omega Logo & Text */}
          <div className="absolute top-[20%] left-1/2 -translate-x-1/2 text-center select-none">
             <div className="text-2xl font-display font-bold text-[#f0f0f0] tracking-wider mb-[-4px]">Ω</div>
             <div className="text-[12px] font-display font-bold text-[#f0f0f0] tracking-[0.2em] leading-tight">OMEGA</div>
             <div className="text-[9px] font-display text-neutral-400 tracking-[0.15em] uppercase font-medium mt-1">Speedmaster</div>
             <div className="text-[9px] font-display text-neutral-400 tracking-[0.1em] uppercase font-medium mt-0.5">PROFESSIONAL</div>
          </div>

          {/* Sub-dials */}
          <SubDial 
            position="left" 
            value={subDialLeftDeg} 
            max={60} 
            label="60" 
            ticks={60}
          />
          <SubDial 
            position="right" 
            value={subDialRightDeg} 
            max={30} 
            label="30" 
            ticks={30}
          />
          <SubDial 
            position="bottom" 
            value={subDialBottomDeg} 
            max={12} 
            label="12" 
            ticks={12}
          />

          {/* Center Post */}
          <div className="absolute top-1/2 left-1/2 w-4 h-4 bg-neutral-900 rounded-full -translate-x-1/2 -translate-y-1/2 z-40 shadow-xl border border-neutral-700" />

          {/* Hour Hand */}
          <motion.div
            className="absolute top-1/2 left-1/2 w-[6px] h-[100px] bg-[#f0f0f0] origin-bottom -translate-x-1/2 z-20 pointer-events-none shadow-2xl"
            style={{ 
              rotate: hourDeg,
              marginTop: "-100px",
              borderRadius: "1px 1px 0 0"
            }}
            transition={{ ease: "linear", duration: 0 }}
          >
             {/* Lume strip */}
             <div className="absolute top-2 left-1/2 -translate-x-1/2 w-[3px] h-[80%] bg-[#d9e6cc] rounded-sm" />
          </motion.div>

          {/* Minute Hand */}
          <motion.div
            className="absolute top-1/2 left-1/2 w-[4px] h-[145px] bg-[#f0f0f0] origin-bottom -translate-x-1/2 z-30 pointer-events-none shadow-2xl"
            style={{ 
              rotate: minuteDeg,
              marginTop: "-145px",
              borderRadius: "1px 1px 0 0"
            }}
            transition={{ ease: "linear", duration: 0 }}
          >
             {/* Lume strip */}
             <div className="absolute top-2 left-1/2 -translate-x-1/2 w-[2px] h-[85%] bg-[#d9e6cc] rounded-sm" />
          </motion.div>

          {/* Chronograph Seconds Hand (The iconic needle) */}
          <motion.div
            className="absolute top-1/2 left-1/2 w-[1.5px] h-[180px] bg-white origin-[50%_85%] -translate-x-1/2 z-40 pointer-events-none"
            style={{ 
              rotate: mainHandDeg,
              marginTop: "-153px"
            }}
            transition={{ 
              type: "spring", 
              stiffness: 400, 
              damping: 40,
              restDelta: 0.001
            }}
          >
             {/* Diamond/Arrow tip */}
             <div className="absolute -top-[8px] left-1/2 -translate-x-1/2 w-2.5 h-2.5 bg-white rotate-45 border-[0.5px] border-neutral-400" />
             {/* Tail counterbalance */}
             <div className="absolute -bottom-[20px] left-1/2 -translate-x-1/2 w-3.5 h-3.5 bg-white rounded-full border border-neutral-400" />
          </motion.div>

        </div>
      </div>
    </div>
  );
}

function SubDial({ position, value, max, label, ticks }: { position: 'left' | 'right' | 'bottom', value: number, max: number, label: string, ticks: number }) {
  const getPositionClasses = () => {
    switch (position) {
      case 'left': return 'top-1/2 left-[24%] -translate-y-1/2 -translate-x-1/2';
      case 'right': return 'top-1/2 right-[24%] -translate-y-1/2 translate-x-1/2';
      case 'bottom': return 'bottom-[24%] left-1/2 translate-y-1/2 -translate-x-1/2';
    }
  };

  return (
    <div className={cn("absolute w-[90px] h-[90px] rounded-full border border-neutral-800 bg-[#151515] shadow-[inset_0_2px_4px_rgba(0,0,0,0.5)]", getPositionClasses())}>
      {/* Ticks */}
      {[...Array(ticks)].map((_, i) => (
        <div
          key={i}
          className={cn(
            "absolute bg-neutral-500 left-1/2 top-0 origin-bottom",
            i % 5 === 0 ? "h-[6px] w-[1.5px] bg-white" : "h-[4px] w-[1px]"
          )}
          style={{ 
            transform: `translateX(-50%) rotate(${i * (360/ticks)}deg)`, 
            transformOrigin: "50% 45px" 
          }}
        />
      ))}
      
      {/* Hand */}
      <motion.div 
        className="absolute top-1/2 left-1/2 w-[2px] h-[40px] bg-white origin-bottom -translate-x-1/2 z-10"
        style={{ 
          marginTop: "-40px",
          rotate: value
        }}
        transition={{ ease: "linear", duration: 0 }}
      />
      <div className="absolute top-1/2 left-1/2 w-1.5 h-1.5 bg-neutral-300 rounded-full -translate-x-1/2 -translate-y-1/2 z-20" />
    </div>
  );
}
