import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const timerHistory = pgTable("timer_history", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // 'chronograph' or 'countdown'
  duration: integer("duration").notNull(), // in milliseconds
  label: text("label"),
  completedAt: timestamp("completed_at").defaultNow(),
});

export const insertTimerHistorySchema = createInsertSchema(timerHistory).omit({ id: true, completedAt: true });

export type TimerHistory = typeof timerHistory.$inferSelect;
export type InsertTimerHistory = z.infer<typeof insertTimerHistorySchema>;
